const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const { v4: uuidv4 } = require('uuid');

const app = express();
app.use(cors());
app.use(bodyParser.json());

// قاعدة بيانات مؤقتة في الذاكرة
let confessions = [];
let settings = { aiType: 'dummy' };

// حفظ اعتراف جديد
app.post('/confessions', (req, res) => {
  const { text } = req.body;
  if (!text) return res.status(400).json({ error: 'النص مطلوب' });
  const confession = { _id: uuidv4(), text, ratings: { like: 0, understand: 0, solidarity: 0 } };
  confessions.unshift(confession); // نضيف في البداية
  res.json(confession);
});

// جلب جميع الاعترافات
app.get('/confessions', (req, res) => {
  res.json(confessions);
});

// تقييم اعتراف
app.post('/confessions/:id/rate', (req, res) => {
  const { id } = req.params;
  const { rateType } = req.body;
  const confession = confessions.find(c => c._id === id);
  if (!confession) return res.status(404).json({ error: 'الاعتراف غير موجود' });
  if (!['like', 'understand', 'solidarity'].includes(rateType)) return res.status(400).json({ error: 'نوع التقييم غير صحيح' });
  confession.ratings[rateType]++;
  res.json({ success: true });
});

// حفظ إعدادات الأدمين
app.post('/admin/settings', (req, res) => {
  const { aiType } = req.body;
  if (!aiType) return res.status(400).json({ error: 'نوع AI مطلوب' });
  settings.aiType = aiType;
  res.json({ success: true, settings });
});

// مثال استدعاء AI (خدمة تجريبية)
app.post('/ai/respond', (req, res) => {
  const { text } = req.body;
  if (!text) return res.status(400).json({ error: 'النص مطلوب' });

  // الرد حسب الإعدادات
  if (settings.aiType === 'openai') {
    // هنا نضع كود الاتصال بـ OpenAI API (غير مفعل الآن)
    return res.json({ response: 'رد الذكاء الاصطناعي عبر OpenAI سيأتي هنا.' });
  } else {
    // خدمة تجريبية مجانية
    const responses = [
      "فهمتك، راه الإحساس اللي كتعيشو صعيب ولكن ماشي مستحيل تجاوزه.",
      "راك ماشي بوحدك، بزاف كيعيشو نفس الشي، وغا تلقى النور قريب.",
      "عندك الحق تبكي وتخرج الهم، ماشي عيب تبان ضعيف." 
    ];
    const randomResponse = responses[Math.floor(Math.random() * responses.length)];
    res.json({ response: randomResponse });
  }
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
